package com.mastering.spring.kotlin.basics

//It is not required to match directories and packages: source files can be placed arbitrarily in the file system

fun main(args: Array<String>) {
	println("Hello, world!")
}