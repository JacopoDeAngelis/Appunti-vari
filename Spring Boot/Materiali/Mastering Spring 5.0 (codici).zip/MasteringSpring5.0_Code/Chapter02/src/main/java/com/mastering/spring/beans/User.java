package com.mastering.spring.beans;

public class User {
  private String id;

  public User(String id) {
    super();
    this.id = id;
  }

  public String getId() {
    return id;
  }
}
